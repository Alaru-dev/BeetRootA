#The birthday greeting program.

name = input("Write your name: ")
age = int(input("Write your age: "))

print(f'Hello {name}, on your next birthday you`ll be {age+1} years.')
