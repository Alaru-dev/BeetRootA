# Save your first and last name
# as separate variables, then use
# string concatenation to add them
# together with a white space in
# between and print a greeting.
name = 'Roman'
surname = "Poberezhnyi"

print('Hello ' + name + ' ' + surname + '! Have a nice day!')