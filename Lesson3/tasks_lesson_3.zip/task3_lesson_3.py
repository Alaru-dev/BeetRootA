a = 10
b = 5

print(f'{a} + {b} = {a+b}') # Addition
print(f'{a} - {b} = {a-b}') # Subtraction
print(f'{a} / {b} = {a/b}') # Division
print(f'{a} * {b} = {a*b}') # Multiplication
print(f'{a} ** {b} = {a**b}') # Exponent (Power)
print(f'{a} % {b} = {a%b}') # Modulus
print(f'{a} // {b} = {a//b}') # Floor division