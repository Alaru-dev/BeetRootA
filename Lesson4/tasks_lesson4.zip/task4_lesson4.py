# The name check.
name_1 = "roman"

ask_name = input('Write your name: ')
if ask_name.lower() == name_1:
    print("True")
else:
    print("Name isn`t correct!")
